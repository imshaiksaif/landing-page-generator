
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'imshaiksaif',
  applicationName: 'landingpage',
  appUid: 'f71ffYLR3nV9p6X7h9',
  orgUid: '2213fcc2-a9d6-4993-9101-f276a175fa2a',
  deploymentUid: '021788eb-ba54-4681-9504-bf53c8ef4ada',
  serviceName: 'landingpage',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.1.4',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'landingpage-dev-graphql', timeout: 6 };

try {
  const userHandler = require('./dist/graphql.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}