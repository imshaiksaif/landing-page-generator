import { ApolloServer, gql } from 'apollo-server-lambda';
import { updateUser, createPage } from "./mutations";
import { allPages } from './queries';

const schema = gql`
  type User {
    userId: String
    createdAt: String
    lastSignedInAt: String
  }

  type LandingPage {
    userId: String
    pageId: String
    createdAt: String
    pageName: String
    content: String
  }


  type Query {
    allPages: [LandingPage] 
  }

  type Mutation {
    updateUser(userId: String): User
    createPage(userId: String, pageName: String): LandingPage
  }
`;

const resolvers = {
  Query: {
    allPages
  },
  Mutation: {
    updateUser,
    createPage
  }
}


const server = new ApolloServer({ typeDefs: schema, resolvers })

export const handler = server.createHandler({
  cors: {
    origin: '*',
    credentials: true
  }
})