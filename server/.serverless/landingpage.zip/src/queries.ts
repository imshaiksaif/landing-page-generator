import { scanItems } from "simple-dynamodb";


export const allPages = async () => {
  // TODO: add pagination
  const result = await scanItems({
    TableName: process.env.PAGE_TABLE!
  });
  return result.Items;
}